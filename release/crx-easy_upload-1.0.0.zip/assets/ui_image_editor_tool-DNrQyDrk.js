import{T as s,b as r,o as l,s as o}from"./index.html-DwOe1WE-.js";import{g as u}from"./helpers-BkXW_su_.js";import"./modulepreload-polyfill-B5Qt9EMX.js";import"./client-2R-putmL.js";import"./_commonjsHelpers-CE1G-McA.js";import"./colors-D8pEQEgW.js";const m=`Your task is to determine which of the following three tools should be used based on the user's goal.

- Annotate → to write or draw shapes on the image.  
- Resize → to change the size of the image (make it larger or smaller).  
- Adjust → to crop or cut the image.

The output must always be in this format:
{"tool": "tool_name"}

If none of the tools match the user’s intent, use "Adjust" by default.

Examples:

input: enlarge my image  
output: {"tool": "Resize"}

input: change the image format to png  
output: {"tool": "Adjust"}`;class b extends s{toolName="ui_image_editor";initialTab;constructor(t){super(t)}async initialize(){const t=await r.getState().promptForTask({prompt:m,content:`input: ${this.goal}`,outputSchema:{tool:"string"},newSession:!0});this.initialTab=Object.keys(t).length!=0&&typeof Object.values(t)[0]=="string"?Object.values(t)[0]:"Adjust",this.initializationSuccess=!0}async exec(t){if(await u(t.inputOPFSFilename)==null)throw console.error("[tool.exec] the file to work on is not found."),"input file doesn't exist or is empty";const e=await l({origin:"task",opfsInputFilename:t.inputOPFSFilename,opfsOutputFilename:this.outputOPFSFilename,initialTab:this.initialTab});if(!await d(e))throw"The image editing window was closed without modifications done."}}function d(i){return new Promise((t,n)=>{o.onMessage.addListener(e=>{e.name=="ui_image_editor_closed"&&e.data.origin=="task"&&t(!0)}),o.onMessage.addListener(e=>{e.name=="window_closed"&&e.data.id==i&&t(!1)})})}export{b as default};
