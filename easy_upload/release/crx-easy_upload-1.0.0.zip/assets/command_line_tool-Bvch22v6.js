import{s as r,T as d,a as h,b as c}from"./index.html-DD1wLjFV.js";import{g as f,d as g,b as x}from"./helpers-BkXW_su_.js";const S=["ui_image_editor","imagemagick","ffmpeg"],w=`Among the proposed commands, you must return the number of the one that best matches the user’s intent.

## Example

**Input:**
user intent: “I want to compress the image to reduce its file size”
tool proposals:
0 - I want to set a specific option for the output format (e.g., compression/size limit or metadata) to control the exported file’s characteristics.
1 - I want to compress the image to make its file size smaller without changing its format.
2 - I want to apply a predefined color correction using a CDL file to adjust the image colors.

**Output:**
{ tool_number: 1 }`,y=`Your task is to modify the command example from the Input based only on the user goal.
Rule: You must use the provided command example as the starting point. Do not use any other commands.
Rule: If output.xxx is in the command example, you must replace xxx with the output format from the user goal.
Rule: Your output must be only the final JSON object.

Input:
{
  "user goal": "I want to convert my image to png",
  "command description": "Converts an image from one format to another. For example PNG to JPEG.",
  "command example": "convert input output.xxx"
}
Output:
{"command": "convert input output.png"}

Input:
{
  "user goal": "I want to stop my video at 42 seconds.",
  "command description": "Keeps only the segment between a start time (-ss) and an end time (-to).",
  "command example": "-i input -ss 00:00:10 -to 00:00:20 -c copy output"
}
Output:
{"command": "-i input -ss 00:00:00 -to 00:00:42 -c copy output"}`;function F(l){return new Promise((o,n)=>{r.onMessage.addListener(e=>{e.name=="exec-command-in-offscreen-resp"&&o(e.data)})})}class I extends d{minisearch;constructor({userTask:o,minisearch:n}){super(o),this.minisearch=n}async initialize(){const o=this.minisearch.search(this.goal,{fuzzy:.4});if(o.length==0){this.initializationSuccess=!1;return}const n=h(o).slice(0,4);console.log(`Potentials commands found by minisearch to satisfy the task "${this.goal}" with the tool "${this.toolName}"`),console.log(n);const e=n.map((t,s)=>`${s} - ${t.intent}`),a=`user intents: ${this.goal}
tool proposal:
${e.join(`
`)} `,i=await c.getState().promptForTask({prompt:w,content:a,outputSchema:{tool_number:"number"},newSession:!0});try{const t=Number(Object.values(i)[0]),s=n[t];console.log("Command selected:"),console.log(s),this.commandSchema=s,this.initializationSuccess=!0}catch{console.error(`Error during tool search for intent : ${this.goal}`),this.initializationSuccess=!1}}async exec(o){const n=await f(o.inputOPFSFilename);if(n==null)throw console.error("[tool.exec] the file to work on is not found."),"input file doesn't exist or is empty";const e=(await g(n))?.ext;var a=this.commandSchema.example;console.log(`[tool.exec] input file format ${e}`),e!=null&&this.commandSchema?.inputType!=null&&e in this.commandSchema.inputType&&(a=this.commandSchema.inputType[e],console.log("[tool.exec] special command found for this filetype"));const i=await c.getState().promptForTask({prompt:y,content:JSON.stringify({"user goal":this.goal,"command description":this.commandSchema.description,"command example":a}),outputSchema:{command:"string"},newSession:!0});let t=Object.values(i)[0];t=S.reduce((u,p)=>u.replaceAll(p,""),t),e!=null&&(t=t.replace(" input ",` input.${e} `)),console.log(`[tool.exec] generated command: ${t}`);const s=x();r.postMessage({name:"exec-command-in-offscreen",data:{id:s,tool:this.toolName,inputOPFSFilename:o.inputOPFSFilename,outputOPFSFilename:this.outputOPFSFilename,command:t}});const m=await F();if(console.log("[tool.exec] Offscreen response"),console.log(m),!m.success)throw"error duting the execution of the worker in the window of the task or timeout"}}export{I as C};
